<?php
echo "
<!DOCTYPE.html>
<html>
<head>
</head>
<body>
    <form id='formMhsw' method='post' action='handler.php'> 
        Nama:
        <input type='text' name='nama'><br>
        Prodi:
        <select name='prodi'>
            <option value='isb'>ISB</option>
            <option value='imt'>IMT</option>
        </select><br>
        <input type='submit' value='Kirim'>
        </form>
</body>
</html>
";
?>