<?php
$nama = $_POST["nama"];
$prodi = $_POST["prodi"];
echo "
<h2>Hasil<h2>
Mahasiswa $nama dari Prodi $prodi
";
?>